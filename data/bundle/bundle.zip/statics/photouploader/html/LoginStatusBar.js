
var loginStatusBar = {
	
	getUserInfoData: {
		jsonresult: []
	},
	
	init: function() {
		staticTexts.init("LoginStatusBar.html");
		window.extender.connect('windowManager', 'eventRaised(QVariantMap)', 'loginStatusBar.onEventRaised');
		window.extender.connect('hyvesApi', 'accessTokenReady()', 'loginStatusBar.loggedIn');
		window.extender.connect('hyvesApi', 'accessTokenRequested()', 'loginStatusBar.loggingIn');

		if (window.hyvesApi.hasAccessToken()) {
			loginStatusBar.loggedIn();
		}
	},

	/**
	 * Following functions get the username and profile picture once we're logged in, and
	 * displays them in the login status bar.
	 */
	loggedIn: function() {
		
		window.extender.connect('hyvesApi', 'resultReady(QDomDocument)', 'loginStatusBar.usersGetCallback');
		window.hyvesApi.doMethod('users.get', 'userid=' + window.hyvesApi.authorizedUserId() + "&" +
											  'ha_responsefields=profilepicture' );
	},
	
	usersGetCallback: function(result) {
		
		window.eval("loginStatusBar.getUserInfoData.jsonresult = " + result);
		if (loginStatusBar.getUserInfoData.jsonresult['users_get_result'] == undefined) { /* not our result */
			return;
		}
		
		var info = loginStatusBar.getUserInfoData.jsonresult['users_get_result']['user'];
		var name = info['displayname'];
		if (name == undefined || name == null) {
			name = info['firstname'];
		}
		var text = tr("Logged in as %s").replace(/%s/, name) + " (" + info['friendscount'] + ") ";
		try { // profile may not have any picture
			this.updateUser(text, info['profilepicture']['icon_small']['src']);
		} catch (err) {
		}
	},
	
	updateUser: function(text, profilePictureUrl) {
		
		var profilePictureImg = document.getElementById('profilephoto');
		if (profilePictureUrl == "") {
			var imgParent = profilePictureImg.parentNode;
			imgParent.removeChild(profilePictureImg);
			var emptyImg = document.createElement('img');
			emptyImg.id = 'profilephoto';
			imgParent.appendChild(emptyImg);
		} else {
			profilePictureImg.src = profilePictureUrl;
		}

		var loginStatusObj = document.getElementById('loginstatus_div');
		var newP = document.createElement('p');
		var newPText = document.createTextNode(text);
		newP.appendChild(newPText);
		newP.id = 'loginstatus_p';
		var currentP = document.getElementById('loginstatus_p');
		currentP.parentNode.removeChild(currentP);
		loginStatusObj.appendChild(newP);
	},

	loggingIn: function() {
		loginStatusBar.updateUser(tr("Logging in"), "");
	},

	loggedOut: function() {
		loginStatusBar.updateUser(tr("Not logged in"), "");
	},
	
	onEventRaised: function(event) {
		if (event.name == 'userLoggedOut') {
			loginStatusBar.loggedOut();
		}
	}

};

