
var staticTexts = {
	init: function(source) {
		if (source == "main.html") {
			staticTexts.translateMain();
		} else if (source == "Geolocation.html") {
			staticTexts.translateGeolocation();
		} else if (source == "LoginStatusBar.html") {
			staticTexts.translateLoginStatusBar();
		}
	},
	
	translateMain: function() {
		trInsert("Add", $('add_photos_text'));
		trInsert("Add from online album", $('add_onlinealbum_text'));
		trInsert("Remove", $('remove_photos_text'));
		trInsert("Re-sort by date taken", $('resort_photos_text'));
		trInsert("Cancel upload", $('cancel_text'));
		trInsert("Retry failed or cancelled uploads", $('retry_text'));
		trInsert("Select a photo (or many) to edit title, description and tags", $('none_selected_message'));
		trInsert("You can click on the 'Upload new photos' tab to add more photos for uploading", $('uploadtab_message'));
		
		trInsert("Edit Photo", $('edit_photo_p'));
		
		trInsert("Title:", $('title_p'));
		trInsert("Description:", $('description_p'));
		trInsert("Tags:", $('tags_p'));
		trInsert("Geotag:", $('geotag_p'));
		trInsert("Edit", $('edit_geolocation_a'));
		
		$('pimp_text').innerHTML = tr("Add Pimps &amp; Effects");
		
		$('select_albums_text').innerHTML = tr("Place in albums and groups");
		$('select_album').innerHTML = tr("Choose album or group");
		$('or_label').innerHTML = tr("or");
		$('new_album').innerHTML = tr("Start new album");
		$('scaleimages_checkbox_text').innerHTML = tr("Resize photos so they are uploaded faster");
		$('upload_button').innerHTML = tr("Upload photos");
		
		trInsert("Current spots", $('spots_text'));
		trInsert("No spots", $('spotted_users'));
		trInsert("Spot", $('spot_button'));
		$('edit_spots_a').innerHTML = tr("Edit");
		
		trInsert("3 reasons for using the Photo Uploader", $("filler_title"));
		trInsert("Fast & easy uploading", $("filler_heading1"));
		trInsert("Upload multiple photos at a time. You can resize photos first, "
		         + "and the uploading is in the background so you don't have to wait!", $("filler_text1"));
		
		trInsert("Titles & tags", $("filler_heading2"));
		trInsert("Add titles & tags to multiple photos with 1 click.", $("filler_text2"));
		
		trInsert("Pimping", $("filler_heading3"));
		trInsert("Add captions, borders or objects!", $("filler_text3"));
	},
	
	translateGeolocation: function() {
		trInsert("Enter an address (e.g. Frederiksplein, Amsterdam) or drop a marker on the map", $('enter_an_address'));
		
		trInsert("Post it to the map", $('post_to_map_button'));
		trInsert("Clear marker(s)", $('clear_marker_button'));
		trInsert("Save", $('save_button'));
	},
	
	translateLoginStatusBar: function() {
	}
};
