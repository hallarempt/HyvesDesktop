
var toUploadTab = {
	isOnTop: true,
	isThumbnailing: false,

	init: function() {
		if (tabwidget.currentIndex == 0)
			toUploadTab.active();
		else
			toUploadTab.obscured();
	},
	active: function() {
		toUploadTab.isOnTop = true;
		metaPanel.updateMarketingPanelVisibility();
		document.getElementById('toupload_taskbar').style.display = 'block';
		document.getElementById('uploading_taskbar').style.display = 'none';
	},
	obscured: function() {
		toUploadTab.isOnTop = false;
		metaPanel.updateMarketingPanelVisibility();
		document.getElementById('toupload_taskbar').style.display = 'none';
		document.getElementById('uploading_taskbar').style.display = 'block';
	},
	thumbnailingStarted: function() {
		toUploadTab.isThumbnailing = true;
		metaPanel.updateBatchSize();
		photoTaskbar.updateButtonStates();
	},
	thumbnailingFinished: function() {
		toUploadTab.isThumbnailing = false;
		metaPanel.updateBatchSize();
		photoTaskbar.updateButtonStates();
	}
};
