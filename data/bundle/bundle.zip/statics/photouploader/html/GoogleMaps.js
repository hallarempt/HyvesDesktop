var googleMaps = {
	map: null,
	geocoder: null,
	markers: [],
	bounds: null,
	options: null,
	MAP_ZOOMLEVEL_STREET: 16,
	MAP_ZOOMLEVEL_CITY: 12,
	MAP_ZOOMLEVEL_COUNTRY: 7,
	MAP_ZOOMLEVEL_WORLD: 2,
	MAP_ZOOMLEVEL_ALMOSTSPACE: 0,

	load: function(div, options) {
		if (typeof(google) == 'undefined') { // network failure, maybe?
			alert("GoogleMaps: Failed to load Google Maps.");
			return;
		}
		var loadOptions = { };
		loadOptions["callback"] = function() { googleMaps.mapsLoaded(div, options); };
		// Only alpha-2 supported. http://spreadsheets.google.com/pub?key=p9pdwsai2hDMsLkXsoM05KQ&gid=1
		loadOptions["language"] = translator.iso6392Language().substring(0, 2).toLowerCase();
		google.load("maps", "2", loadOptions);
	},

	unload: function() {
		GUnload();
	},

	isLoaded: function() {
		return googleMaps.map != null;
	},
	
	mapsLoaded: function(div, options) {
		if (!GBrowserIsCompatible()) {
			alert("GoogleMaps: Browser is not compatible");
			return;
		}

		var mapOptions = { };
		if (options.width || options.height)
			mapOptions["size"] = new GSize(options.width, options.height);
		googleMaps.map = new GMap2(div, mapOptions);
		googleMaps.options = options;
		googleMaps.geocoder = new GClientGeocoder(new GGeocodeCache());
		googleMaps.bounds = new GLatLngBounds();

		if (options.type != "tiny") {
			googleMaps.map.addControl(new GLargeMapControl());
			googleMaps.map.addControl(new GMapTypeControl());

			var center = new GLatLng(52.3603609, 4.8995567);
			googleMaps.map.setCenter(center, googleMaps.MAP_ZOOMLEVEL_CITY);
		} else {
			var center = new GLatLng(0, 180);
			googleMaps.map.setCenter(center, googleMaps.MAP_ZOOMLEVEL_ALMOSTSPACE);

			div.style.overflow = "hidden"; 
			// div.firstChild.nextSibling.style.display = 'none'; // "Google" logo
			div.firstChild.nextSibling.nextSibling.style.display = 'none'; // Copyright
		}
		googleMaps.map.enableScrollWheelZoom();
		googleMaps.map.enableContinuousZoom();
		
		if (options.callback)
			options.callback();
	},

	showLocation: function(location, callback) {
		googleMaps.geocoder.getLocations(location, function(response) { googleMaps.addAddressToMap(response, callback); });
	},

	addAddressToMap: function(response, callback) {
		if (!response || response.Status.code != 200) {
			callback(tr('Sorry, we couldn\'t find that address...'));
		} else {
			var place = response.Placemark[0];
			callback('', place);
		}
	},

	addMarker: function(point, zoomLevel, userData) {
		var marker = new GMarker(point, {draggable: (googleMaps.options.type != "tiny") });
		marker.userData = userData;
		googleMaps.markers.push(marker);
		googleMaps.map.addOverlay(marker);
		if (zoomLevel != null) {
			googleMaps.map.setCenter(point, zoomLevel);
		}
		googleMaps.bounds.extend(point);
		return marker;
	},

	removeMarker: function(marker) {
		googleMaps.map.removeOverlay(marker);
		googleMaps.markers.splice(googleMaps.markers.indexOf(marker), 1);
		// bounds not updated intentionally
	},

	removeMarkers: function() {
		googleMaps.map.clearOverlays();
		googleMaps.markers = new Array();
		googleMaps.bounds = new GLatLngBounds();
	},

	zoomFit: function() {
		var zoom = googleMaps.map.getBoundsZoomLevel(googleMaps.bounds);
		zoom = Math.min(zoom, 14);
		var center = googleMaps.bounds.getCenter();
		googleMaps.map.setCenter(center, zoom);
	}
};

