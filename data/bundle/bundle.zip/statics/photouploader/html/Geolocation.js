var geolocation = {
	selectedPhotos: [],
	info: null,
	exifCount: 0,
	clearMarkerButton: [],
	activeMarker: null,

	onload: function() {
		staticTexts.init("Geolocation.html");
		googleMaps.load(document.getElementById("map"), { type: "large", callback: geolocation.onmapload });
		geolocation.info = document.getElementById('info_div');
		geolocation.clearMarkerButton = document.getElementById('clear_marker_button');
	},

	onunload: function() {
		googleMaps.unload();
	},

	setInfo: function(text, classname) {
		geolocation.info.className = classname ? classname : 'normal';
		geolocation.info.innerText = text;
	},

	infoWindowHtml: function(marker) {
		var index = marker.userData.index;
		if (index == null) {
			var text = tr("This marker applies to %n photos").replace(/%n/, "" + geolocation.selectedPhotos.length);
			var html = '<div> ' + text 
					   + '<br><br>'
				   	   + '<img onclick="geolocation.removeActiveMarker()" style="cursor: pointer; float:right" src="http://localhost/statics/photouploader/images/deletebutton.png"> </img>'
					   + '</div>';
		} else {
			var title = photomodel.title(index);
			var iconSrc = "http://localhost/photomodel/" + index + "/image?width=75&height=60&rnd=" + Math.random();
			var html = '<div> <span style="margin-left:10px">   ' + title + '</span>'
					   + '<img style="float: left" src="' + iconSrc + '"> </img>';
			html += '<br><br><img onclick="geolocation.removeActiveMarker()" style="cursor: pointer; float:right" src="http://localhost/statics/photouploader/images/deletebutton.png"> </img>'
			html += '</div>';
		}
		return html;
	},

	addMarker: function(pt, zoom, userData) {
		var marker = googleMaps.addMarker(pt, zoom, userData);
		geolocation.clearMarkerButton.disabled = false;
		geolocation.clearMarkerButton.style.display = 'block';
		GEvent.addListener(marker, "mousedown", function() { 
			geolocation.setInfo(''); 
			this.closeInfoWindow();
		});
		GEvent.addListener(marker, "dragstart", function() {
			geolocation.clearMarkerButton.disabled = false;
			geolocation.clearMarkerButton.style.display = 'block';
		});
	},

	addMultiPhotoMarker: function(point, zoom) {
		geolocation.addMarker(point, zoom, { index: null });
	},

	isMultiPhotoMarker: function(marker) {
		return marker && marker.userData.index == null;
	},

	isSinglePhotoMarker: function(marker) {
		return marker && marker.userData.index != null;
	},

	addMarkers: function(selectedPhotos) {
		for (var i = 0; i < selectedPhotos.length; i++) {
			var latitude = photomodel.latitude(selectedPhotos[i]);
			var longitude = photomodel.longitude(selectedPhotos[i]);

			if (latitude != 0xDEAD || longitude != 0xDEAD) {
				geolocation.addMarker(new GLatLng(latitude, longitude), googleMaps.MAP_ZOOMLEVEL_STREET, 
									 { index: selectedPhotos[i] });
			}
		}
	},

	removeActiveMarker: function() {
		googleMaps.removeMarker(geolocation.activeMarker);
		geolocation.clearMarkerButton.disabled = googleMaps.markers.length == 0;
	},

	queryRemoveMarkers: function() {
		if (geolocation.selectedPhotos.length > 1) {
			if (!confirm(tr("Do you want to remove the Geotag markers of %n photo(s)?")
							.replace(/%n/, "" + geolocation.selectedPhotos.length)))
				return;
		}
		geolocation.clearMarkerButton.disabled = true;
		googleMaps.removeMarkers();
	},

	onmapload: function() {
		GEvent.addListener(googleMaps.map, "click", geolocation.onmapclick);
	},
	
	onmapclick: function(marker, point) {
		if (marker && marker.userData == undefined) // is it really a marker?
			return;

		geolocation.setInfo('');
		geolocation.activeMarker = marker;

		if (marker) {
			marker.openInfoWindowHtml(geolocation.infoWindowHtml(marker));
			return;
		}

		if (geolocation.selectedPhotos.length > 1) {
			if  (geolocation.isSinglePhotoMarker(googleMaps.markers[0])) {
				if (!confirm(tr("%m photo(s) are already geotagged. Do you want to use this location for all photos?")
								.replace(/%m/g, "" + googleMaps.markers.length)))
					return;
			}

			googleMaps.removeMarkers();
			geolocation.addMultiPhotoMarker(point);
		} else {
			googleMaps.removeMarkers();
			geolocation.addMarker(point, null, { index: geolocation.selectedPhotos[0] });
		}
	},

	showLocation: function() {
		var cs = document.getElementById('country_combobox');
		var countrytext = "";
		if (cs.length > 0) {
			var country = cs.options[cs.selectedIndex].text;
			var length = country.indexOf(' (');
			countrytext = country.substr(0, length == -1 ? country.length : length);
		}

		document.getElementById('img_busy').style.display = 'inline';
		var address = document.getElementById('address_lookup').value;
		googleMaps.showLocation(address + ' ' + countrytext, geolocation.showLocationResult);
	},

	showLocationResult: function(result, place) {
		document.getElementById('img_busy').style.display = 'none';
		if (place == null) {
			geolocation.setInfo(result, 'error');
			return;
		}

		geolocation.setInfo('');

		var point = new GLatLng(place.Point.coordinates[1], place.Point.coordinates[0]);
		var markers = googleMaps.markers;
		if (geolocation.selectedPhotos.length == 1) {
			googleMaps.removeMarkers();
			var selectedPhotos = geolocation.selectedPhotos;

			geolocation.addMarker(new GLatLng(point.lat(), point.lng()), googleMaps.MAP_ZOOMLEVEL_STREET, 
	 							  { index: selectedPhotos[0] });
			geolocation.setInfo(tr("Geotag of photo set to new location"));
		} else if (geolocation.isSinglePhotoMarker(markers[0])) {
			googleMaps.map.setCenter(point, googleMaps.MAP_ZOOMLEVEL_STREET);
			if (!confirm(tr("%m photo(s) are already geotagged. Do you want to use this location for all photos?")
							.replace(/%m/g, "" + markers.length)))
				return;
			googleMaps.removeMarkers();
			geolocation.addMultiPhotoMarker(point);
		} else {
			googleMaps.removeMarkers();
			geolocation.addMultiPhotoMarker(point, googleMaps.MAP_ZOOMLEVEL_STREET);
			geolocation.setInfo(tr("Geotag of photo set to new location"));
		}
	},

	setTeaser: function(imageSrc) {
		var teaserDiv = document.getElementById('teaser_div');
		for (var i = 0; i < teaserDiv.children.length; i++)
			teaserDiv.removeChild(teaserDiv.children.item(i));

		var teaserImg = null;
		if (imageSrc != "") {
			teaserImg = document.createElement('img');
			teaserImg.src =  imageSrc;
		} else {
			teaserImg = document.createElement('span');
			teaserImg.innerText = tr("%n photos selected").replace(/%n/, "" + geolocation.selectedPhotos.length);
		}
		teaserDiv.appendChild(teaserImg);
	},

	updateImageTeaser: function() {
		var selectedPhotos = geolocation.selectedPhotos;
		if (selectedPhotos.length == 1) {
			var iconSrc = "http://localhost/photomodel/" + selectedPhotos[0] + "/image?width=120&height=80&rnd=" + Math.random();
			geolocation.setTeaser(iconSrc);
		} else {
			geolocation.setTeaser("");
		}
	},

	populateCountryList: function() {
		var countriesComboBox = document.getElementById('country_combobox');
		if (countriesComboBox.length > 0)
			return;
		var countries = eval(mainwindow.serverData("countriesJSON"));
		if (countries == null)
			return;
		countries.sort();
		for(var i = 0; i < countries.length; i++) {
			var opt = document.createElement("option");
			opt.value = i.toString();
			opt.innerText = countries[i];
			countriesComboBox.appendChild(opt);
			if (countries[i] == "Netherlands")
				countriesComboBox.selectedIndex = i;
		}
	},

	init: function(selectedPhotos) {
		geolocation.selectedPhotos = selectedPhotos;
		geolocation.updateImageTeaser();
		geolocation.populateCountryList();

		googleMaps.removeMarkers();

		geolocation.setInfo('');
		geolocation.addMarkers(selectedPhotos);

		if (googleMaps.markers.length != 0) {
			googleMaps.zoomFit();
			geolocation.clearMarkerButton.disabled = false;
			geolocation.clearMarkerButton.style.display = 'block';
		} else {
			geolocation.clearMarkerButton.disabled = true;
			geolocation.clearMarkerButton.style.display = 'none';
		}
	},

	setModelData: function(index, latitude, longitude, altitude) {
		photomodel.setGeolocation(index, latitude, longitude, altitude);
	},

	save: function() {
		var markers = googleMaps.markers;
		var selectedPhotos = geolocation.selectedPhotos;
		if (markers.length == 0) {
			for (var i = 0; i < selectedPhotos.length; i++)
				geolocation.setModelData(selectedPhotos[i], 0xDEAD, 0xDEAD, 0xDEAD);
		} else if (geolocation.isMultiPhotoMarker(markers[0])) {
			for (var i = 0; i < selectedPhotos.length; i++) {
				var point = markers[0].getLatLng();
				geolocation.setModelData(selectedPhotos[i], point.lat(), point.lng(), 0);
			}
		} else {
			var savedIndices = [];
			for (var i = 0; i < markers.length; i++) {
				var point = markers[i].getLatLng();
				var index = markers[i].userData.index;
				geolocation.setModelData(index, point.lat(), point.lng(), 0);
				savedIndices.push(index);
			}
			for (var i = 0; i < selectedPhotos.length; i++) {
				if (savedIndices.indexOf(selectedPhotos[i]) == -1) {
					geolocation.setModelData(selectedPhotos[i], 0xDEAD, 0xDEAD, 0xDEAD);
				}
			}
		}
	}
};

function windowResized(x, y) {
	var map = document.getElementById("map");
	map.style.width = (x - parseInt(map.offsetLeft) - 15) + "px";
	map.style.height = (y - parseInt(map.offsetTop) - 15) + "px";
}

