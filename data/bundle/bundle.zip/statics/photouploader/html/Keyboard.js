/**
 * Key event handling functions to enable tab, backtab and accesskeys
 * are handled correctly even when focus is on an embedded web plugin.
 */
var keyboard = {
	accessKeyMap: [], // map[accesskey] = htmlobject;
	init: function() {
		this.refreshAccessKeyMap();
	},

	/**
	 * refreshAccessKeyMap reads accesskeys from the html and registers them
	 * with the WebObjectAccessKeyHandler static instance
	 */
	refreshAccessKeyMap: function() {
		var accessKeyTags = ['a', 'input', 'textarea'];
		for (var i = 0; i < accessKeyTags.length; i++) {
			var tag = accessKeyTags[i];
			var elements = document.getElementsByTagName(tag);
			for (var j = 0; j < elements.length; j++) {
				if (elements[j].accessKey != undefined && elements[j].accessKey != "") {
					var key = elements[j].accessKey.toLowerCase();
					this.accessKeyMap[key] = elements[j];
					window.acceskeyhandler.addAccessKey(key);
				}
			}
		}
	},

	/**
	 * accessKeyEventHandler gets called when an accesskey is invoked when the
	 * focus is on an embedded web plugin.
	 */
	accessKeyEventHandler: function(key) {
		var obj = this.accessKeyMap[key.toLowerCase()];
		if (obj == undefined || typeof(obj) == undefined || obj.tagName == undefined)
			return;
		if (obj.tagName.toLowerCase() == "a") {
			var target = "" + obj; // convert to string
			if (target.search(/^javascript:/i) != -1) {
				target.replace(/^javascript:/i, "");
				eval(target);
				return;
			} else if (target != "undefined" && target != "null" && target != "") {
				window.location.href = target;
			}
		} else if (obj.tagName.toLowerCase() == "input") {
			obj.focus();
		} else if (obj.tagName.toLowerCase() == "textarea") {
			obj.focus();
		}
	},

	/**
	 * The following event handlers get called when focus moves out of an embedded web plugin.
	 * These handlers determine the object that should get focus next.
	 */
	photoviewKeyEventHandler: function(key) {
		if (key.toLowerCase() == "tab") {
			if (document.getElementById('pimp_button').style.display != "none")
				document.getElementById('pimp_button').focus();
			else
				metaPanel.titleInput.focus();
		}
		if (key.toLowerCase() == "backtab") {
			if (toUploadTab.isOnTop) {
				if (!photoTaskbar.resortButton.disabled)
					photoTaskbar.resortButton.focus();
				else if (!photoTaskbar.removeButton.disabled)
					photoTaskbar.removeButton.focus();
				else
					photoTaskbar.addButton.focus();
			} else {
				photoTaskbar.uploadRetryButton.focus();
			}
		}
	},
	unselectedAlbumsKeyEventHandler: function(key) {
		if (key.toLowerCase() == "tab") {
			document.getElementById('selectedalbums_href').focus();
		}
		if (key.toLowerCase() == "backtab") {
			metaPanel.createAlbumButton.focus();
		}
	},
	selectedAlbumsKeyEventHandler: function(key) {
		if (key.toLowerCase() == "tab") {
			metaPanel.scaleImagesCheckbox.focus();
		}
		if (key.toLowerCase() == "backtab") {
			document.getElementById('unselectedalbums_href').focus();
		}
	}
};
