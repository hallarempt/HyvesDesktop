
var photoTaskbar = {
	removeButton: null,
	resortButton: null,
	
	init: function() {
		
		photoTaskbar.addButton = document.getElementById('photo_addbutton');
		photoTaskbar.addFromOnlineAlbumButton = document.getElementById('photo_addFromOnlineAlbumButton');
		photoTaskbar.removeButton = document.getElementById('photo_removebutton');
		photoTaskbar.resortButton = document.getElementById('photo_resortbutton');
		photoTaskbar.cancelButton = document.getElementById('upload_cancelbutton');
		photoTaskbar.retryButton = document.getElementById('upload_retrybutton');
		photoTaskbar.enableButton(photoTaskbar.addButton);
		photoTaskbar.enableButton(photoTaskbar.addFromOnlineAlbumButton);
		photoTaskbar.disableButton(photoTaskbar.removeButton);
		photoTaskbar.disableButton(photoTaskbar.resortButton);
		photoTaskbar.disableButton(photoTaskbar.cancelButton);
		photoTaskbar.enableButton(photoTaskbar.retryButton);
	},
	
	/**
	 * update enables/disables buttons based on the current selection
	 */
	update: function() {
		
		var selectedPhotos = window.tabwidget.selectedPhotos();
		if (selectedPhotos.length <= 0) {
			photoTaskbar.disableButton(photoTaskbar.removeButton);
		} else {
			photoTaskbar.enableButton(photoTaskbar.removeButton);
		}
	},
	
	/**
	 * updateButtonStates enables/disables buttons based on thumbnailing status
	 */
	updateButtonStates: function() {
		
		if (toUploadTab.isThumbnailing || window.photoview.photoCount() <= 1) {
			photoTaskbar.disableButton(photoTaskbar.resortButton);
		} else {
			photoTaskbar.enableButton(photoTaskbar.resortButton);
		}
	},
	
	/**
	 * uploadStarted and uploadFinished enable/disable cancel and retry buttons appropriately
	 */
	uploadStarted: function() {
		
		photoTaskbar.enableButton(photoTaskbar.cancelButton);
		photoTaskbar.disableButton(photoTaskbar.retryButton);
	},
	
	uploadFinished: function(success) {
		
		photoTaskbar.disableButton(photoTaskbar.cancelButton);
		if (!success) {
			photoTaskbar.enableButton(photoTaskbar.retryButton);
		}
	},
	
	/**
	 * disableButton disables a button
	 */
	disableButton: function(button) {
		
		button.className = 'photo_taskbutton_disabled';
		button['disabled'] = true;
		if (button.tabIndex > 0) {
			button.tabIndex = -button.tabIndex;
		}
	},
	
	/**
	 * enableButton enables a button
	 */
	enableButton: function(button) {
		
		button.className = 'photo_taskbutton';
		button['disabled'] = false;
		if (button.tabIndex < 0) {
			button.tabIndex = -button.tabIndex;
		}
	},
	
	/**
	 * Following functions handle button click events on the photo taskbar
	 */
	addClicked: function() {
		
		if (!photoTaskbar.addButton.disabled) {
			window.photoview.addPhotos();
		}
	},
	
	addFromOnlineAlbumClicked: function() {
		
		if (!photoTaskbar.addFromOnlineAlbumButton.disabled) {
			window.mainwindow.addFromOnlineAlbum();
		}
	},
	
	removeClicked: function() {
		
		if (!photoTaskbar.removeButton.disabled) {
			window.photoview.removeSelectedPhotos();
		}
	},
	
	resortClicked: function() {
		
		if (!photoTaskbar.resortButton.disabled) {
			window.photomodel.sortPhotos();
		}
	},
	
	cancelClicked: function() {
		
		if (!photoTaskbar.cancelButton.disabled) {
			window.mainwindow.cancelUpload();
		}
	},
	
	retryClicked: function() {
		
		if (!photoTaskbar.retryButton.disabled) {
			window.mainwindow.retryUpload();
		}
	}
};
