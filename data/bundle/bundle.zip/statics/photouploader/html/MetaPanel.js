
templates.addFromString('photouploader.album',
	'<div class="album">' +
		'<input type="checkbox" onclick="var albumId = this.id.substr(6); this.checked ? albumsmodel.select(albumId) : albumsmodel.deselect(albumId, true)" id="album_${album.id}" {if album.selected} checked="checked"{/if} />' +
		'<label for="album_${album.id}">${album.title}</label>' +
	'</div>'
);

var metaPanel = {
	lastSelection: [],
	metaFormEnabledClassName: "meta_form",
	metaFormDisabledClassName: "meta_form_disabled",
	editPhotoMsg: null,
	titleInput: null,
	descriptionInput: null,
	tagsInput: null,
	noneSelectedMsg: null,
	manySelectedMsg: null,
	uploadButton: null,
	titleUnsaved: false,
	descriptionUnsaved: false,
	tagsUnsaved: false,
	isLoading: false,
	geotagLink: null,
	spottedUsers: null,
	spotLink: null,
	blockRefresh: false,
	
	init: function() {
		
		metaPanel.editPhotoMsg = $('edit_photo_p');
		metaPanel.titleInput = document.forms.meta_panel_form.title_input;
		metaPanel.descriptionInput = document.forms.meta_panel_form.description_input;
		metaPanel.tagsInput = document.forms.meta_panel_form.tags_input;
		metaPanel.noneSelectedMsg = $('none_selected_message');
		metaPanel.manySelectedMsg = $('many_selected_message');
		metaPanel.metaPhotoPreview = $('meta_photo_preview');
		metaPanel.metaBatchSize = $('meta_batch_size');
		metaPanel.uploadTabMsg = $('uploadtab_message');
		metaPanel.uploadButton = $('upload_button');
		metaPanel.scaleImagesCheckbox = $('scaleimages_checkbox');
		metaPanel.createAlbumButton = $('create_album_button');
		metaPanel.geotagLink = $('edit_geolocation_a');
		metaPanel.spottedUsers = $('spotted_users');
		metaPanel.spotLink = $('edit_spots_a');
		metaPanel.spotButton = $('spot_button');
		metaPanel.editSpots = $('edit_spots_span');
		
		metaPanel.titleInput.onfocus = metaPanel.titleInput.onclick = metaPanel.titleInput.onkeypress =
				function() { metaPanel.titleUnsaved = true; };
		metaPanel.descriptionInput.onfocus = metaPanel.descriptionInput.onclick = metaPanel.descriptionInput.onkeypress =
				function() { metaPanel.descriptionUnsaved = true; };
		metaPanel.tagsInput.onfocus = metaPanel.tagsInput.onclick =  metaPanel.tagsInput.onkeypress =
				function() { metaPanel.tagsUnsaved = true; };
		metaPanel.titleInput.onchange = metaPanel.saveTitle;
		metaPanel.descriptionInput.onchange = metaPanel.saveDescription;
		metaPanel.tagsInput.onchange = metaPanel.saveTags;
		metaPanel.scaleImagesCheckbox.onclick = metaPanel.updateBatchSize;
		
		// change main.css if you change the width/height
		googleMaps.load($('map'), { type: 'tiny', width: 170, height: 100 });
		$('marketing_panel').style.display = 'block';
		metaPanel.hidePimp();
		
		this.albumModelLoaded();
	},
	
	/**
	 * update refreshes the meta panel based on the current selection. It also saves title and
	 * description to the last selection if applicable.
	 */
	update: function() {
		
		var selectedPhotos = window.tabwidget.selectedPhotos();
		if (toUploadTab.isOnTop) {
			metaPanel.blockRefresh = true;
			metaPanel.save();
			metaPanel.blockRefresh = false;
			metaPanel.lastSelection = selectedPhotos;
		}

		metaPanel.refresh();
	},
	
	refresh: function() {
		if (metaPanel.blockRefresh) {
			return;
		}
		var selectedPhotos = metaPanel.lastSelection;

		if (selectedPhotos.length == 1) {
			metaPanel.setTitle(window.photomodel.title(selectedPhotos[0]));
			metaPanel.setDescription(window.photomodel.description(selectedPhotos[0]));
			metaPanel.setTags(window.photomodel.tags(selectedPhotos[0]));
		} else {
			metaPanel.setTitle("");
			metaPanel.setDescription("");
			metaPanel.setTags("");
		}
		
		if (selectedPhotos.length == 1) {
			metaPanel.showPhotoPreview(selectedPhotos[0]);
		}
		metaPanel.updateMetaContextMessage(selectedPhotos.length);
		if (selectedPhotos.length <= 0) {
			this.disableMetaPanel();
			this.clearMetaPanel();
		} else if (!toUploadTab.isOnTop) {
			this.disableMetaPanel();
		} else {
			this.enableMetaPanel();
			if (selectedPhotos.length == 1 && !window.photomodel.isVideo(selectedPhotos[0])) {
				metaPanel.showPimp();
				metaPanel.enableLink(metaPanel.spotLink);
			} else {
				metaPanel.hidePimp();
				metaPanel.disableLink(metaPanel.spotLink);
			}
		}
		
		metaPanel.updateMap();
		metaPanel.updateSpots();
	},
	
	updateMarketingPanelVisibility: function() {
		
		if (!toUploadTab.isOnTop || window.photoview.photoCount() == 0) {
			$('upload_box').style.display = 'none';
			$('meta_panel').style.display = 'none';
			$('marketing_panel').style.display = 'block';
		} else {
			$('upload_box').style.display = 'block';
			$('meta_panel').style.display = 'block';
			$('marketing_panel').style.display = 'none';
		}
	},

	/**
	 * updateMetaContextMessage shows the right message above the 'title' input box based on
	 * how many photos are selected.
	 */
	updateMetaContextMessage: function(selectedPhotosCount) {
		
		if (toUploadTab.isOnTop) {
			metaPanel.uploadTabMsg.style.display = 'none';
			if (selectedPhotosCount == 0) {
				metaPanel.noneSelectedMsg.style.display = 'block';
				metaPanel.manySelectedMsg.style.display = 'none';
				metaPanel.metaPhotoPreview.style.display = 'none';
				metaPanel.editPhotoMsg.innerText = tr('Edit Photo');
				metaPanel.hidePimp();
			} else if (selectedPhotosCount == 1) {
				metaPanel.noneSelectedMsg.style.display = 'none';
				metaPanel.manySelectedMsg.style.display = 'none';
				metaPanel.metaPhotoPreview.style.display = 'table-cell';
				metaPanel.editPhotoMsg.innerText = tr('Edit Photo');
				metaPanel.showPimp();
			} else {
				metaPanel.noneSelectedMsg.style.display = 'none';
				metaPanel.manySelectedMsg.innerHTML =
					tr("You have selected <b>%n photos</b> to edit (title, tags, description & geotag). You can pimp a photo by selecting a single photo.")
						.replace(/%n/, "" + selectedPhotosCount);
				metaPanel.manySelectedMsg.style.display = 'block';
				metaPanel.editPhotoMsg.innerText = tr('Edit Photos');
				metaPanel.hidePimp();
				metaPanel.metaPhotoPreview.style.display = 'none';
			}
		} else {
			metaPanel.noneSelectedMsg.style.display = 'none';
			metaPanel.manySelectedMsg.style.display = 'none';
			metaPanel.uploadTabMsg.style.display = 'block';
			metaPanel.hidePimp();
			metaPanel.metaPhotoPreview.style.display = 'none';
			if (selectedPhotosCount == 1) {
				metaPanel.uploadTabMsg.style.display = 'none';
				metaPanel.metaPhotoPreview.style.display = 'table-cell';
			}
		}
	},
	
	/**
	 * showPhotoPreview displays a thumbnail of the selected photo
	 * if there's exactly one photo selected.
	 */
	showPhotoPreview: function(photoId) {
		
		callOnAllDaughters(metaPanel.metaPhotoPreview,
			function(node) { if (node.tagName != undefined) node.parentNode.removeChild(node); }
		);
		var metaPhotoPreviewImgObj = document.createElement("img");
		// the size 150x100 below comes from the size of meta_photo_preview in main.css
		metaPhotoPreviewImgObj.src =  "http://localhost/photomodel/" + photoId + "/image?width=150&height=100&rnd=" + Math.random();
		metaPanel.metaPhotoPreview.appendChild(metaPhotoPreviewImgObj);
	},
	
	/**
	 * photoOrderChanged is invoked when the order of the photos is changed.
	 * It refreshes the indices to which any title/description will be saved next.
	 */
	photoOrderChanged: function() {
		
		metaPanel.lastSelection = window.tabwidget.selectedPhotos();
	},
	
	/**
	 * Following functions load/store title and description
	 */
	setTitle: function(str) {
		
		metaPanel.titleInput.value = str;
	},
	
	setDescription: function(str) {
		
		metaPanel.descriptionInput.value = str;
	},
	
	setTags: function(str) {
		
		metaPanel.tagsInput.value = str;
	},
	
	saveTitle: function() {
		
		metaPanel.saveTitleToSelection(window.tabwidget.selectedPhotos());
	},
	
	saveDescription: function() {
		
		metaPanel.saveDescriptionToSelection(window.tabwidget.selectedPhotos());
	},
	
	saveTags: function() {
		
		metaPanel.saveTagsToSelection(window.tabwidget.selectedPhotos());
	},

	saveTitleToSelection: function(selection) {
		if (metaPanel.titleUnsaved) {
			for (var i = 0; i < selection.length; i++) {
				window.photomodel.setTitle(selection[i], metaPanel.titleInput.value);
				// alert("saved " + selection[i] + " << " + metaPanel.titleInput.value + " got " + window.photomodel.title(selection[i]) );
			}
			metaPanel.titleUnsaved = false;
		}
	},
	saveDescriptionToSelection: function(selection) {
		if (metaPanel.descriptionUnsaved) {
			for (var i = 0; i < selection.length; i++) {
				var base = "";
				// if more than one photo selected, append to existing stuff
				if (selection.length > 1) {
					base = window.photomodel.description(selection[i]);
					if (base.search(/\S/) >= 0)
						base += "\n";
				}
				window.photomodel.setDescription(selection[i], base + metaPanel.descriptionInput.value);
			}
			metaPanel.descriptionUnsaved = false;
		}
	},
	saveTagsToSelection: function(selection) {
		if (metaPanel.tagsUnsaved) {
			for (var i = 0; i < selection.length; i++) {
				var base = "";
				// if more than one photo selected, append to existing stuff
				if (selection.length > 1)
					base = window.photomodel.tags(selection[i]) + " ";
				window.photomodel.setTags(selection[i], uniquifyTags(base + metaPanel.tagsInput.value));
			}
			metaPanel.tagsUnsaved = false;
		}
	},
	save: function() {
		metaPanel.saveTitleToSelection(metaPanel.lastSelection);
		metaPanel.saveDescriptionToSelection(metaPanel.lastSelection);
		metaPanel.saveTagsToSelection(metaPanel.lastSelection);
	},

	/**
	 * Displays the location of selected photos on the map.
	 */
	updateMap: function() {
		if (!googleMaps.isLoaded())
			return;
		googleMaps.removeMarkers();
		var selectedPhotos = tabwidget.selectedPhotos();
		for (var i = 0; i < selectedPhotos.length; i++) {
			var latitude = photomodel.latitude(selectedPhotos[i]);
			var longitude = photomodel.longitude(selectedPhotos[i]);

			if (latitude != 0xDEAD) {
				var point = new GLatLng(latitude, longitude);
				googleMaps.addMarker(point);
			}
		}

		googleMaps.zoomFit();
	},
	/**
	  * Displays the current spotted users.
	  */
	updateSpots: function() {
		var selectedPhotos = tabwidget.selectedPhotos();
		if (selectedPhotos.length == 1) {
			var spots = photomodel.spottedUsers(selectedPhotos[0]);
			if (spots.length != 0) {
				var html = "";
				for (var j = 0; j < spots.length; j++) {
					var fullName = friendsmodel.fullName(spots[j]);
					var imageUrl = "http://localhost/friendsmodel/" + spots[j] + "/image?width=25&height=25&rnd=" + Math.random();
					html += "<img src='" + imageUrl + "' title='"  + fullName + "'/> ";
				}
				metaPanel.spottedUsers.style.display = 'block';
				metaPanel.spottedUsers.innerHTML = html;
				metaPanel.spotButton.style.display = 'none';
				metaPanel.editSpots.style.visibility = 'visible';
			} else {
				metaPanel.spottedUsers.style.display = 'none';
				metaPanel.spotButton.style.display = 'block';
				metaPanel.editSpots.style.visibility = 'hidden';
			}
		} else {
			metaPanel.spottedUsers.innerHTML = '';
			metaPanel.spottedUsers.style.display = 'block';
			metaPanel.spotButton.style.display = 'none';
			metaPanel.editSpots.style.visibility = 'hidden';
		}
	},
	editGeolocation: function() {
		if (photoview.selectedPhotos().length == 0 || metaPanel.geotagLink.disabled)
			return;
		mainwindow.editGeolocation();
	},
	pimp: function() {
		if (photoview.selectedPhotos().length == 0)
			return;
		mainwindow.pimp();
	},
	spot: function() {
		if (photoview.selectedPhotos().length == 0)
			return;
		mainwindow.spot();
	},
	/**
	 * Following functions enable, disable or clear all title/description forms
	 */
	clearMetaPanel: function() {
		var forms = document.getElementsByTagName('form');
		for (var i = 0; i < forms.length; i++) {
			if (forms[i].className == metaPanel.metaFormEnabledClassName) {
				forms[i].className = metaPanel.metaFormDisabledClassName;
				callOnAllDaughters(forms[i],
									function(node) {
										if (node.tagName  == undefined)
											return;
										if (node.tagName.toUpperCase() == 'INPUT' ||
											node.tagName.toUpperCase() == 'TEXTAREA') {
											node.value = '';
										}
									}
								  );
			}
		}
	},
	disableMetaPanel: function() {
		var forms = document.getElementsByTagName('form');
		for (var i = 0; i < forms.length; i++) {
			if (forms[i].className == metaPanel.metaFormEnabledClassName) {
				forms[i].className = metaPanel.metaFormDisabledClassName;
				callOnAllDaughters(forms[i],
									function(node) {
										if (node.tagName  == undefined)
											return;
										if (node.tagName.toUpperCase() == 'INPUT' ||
											node.tagName.toUpperCase() == 'TEXTAREA') {
											node.disabled = true;
										}
									}
								  );
			}
		}
		// elements not inside <form>
		metaPanel.disableLink(metaPanel.geotagLink);
		metaPanel.hidePimp();
		metaPanel.disableLink(metaPanel.spotLink);
	},
	enableMetaPanel: function() {
		var forms = document.getElementsByTagName('form');
		for (var i = 0; i < forms.length; i++) {
			if (forms[i].className == metaPanel.metaFormDisabledClassName) {
				forms[i].className = metaPanel.metaFormEnabledClassName;
				callOnAllDaughters(forms[i],
									function(node) {
										if (node.tagName  == undefined)
											return;
										if (node.tagName.toUpperCase() == 'INPUT' ||
											node.tagName.toUpperCase() == 'TEXTAREA') {
											node.disabled = false;
										}
									}
								  );
			}
		}
		// elements not inside <form>
		metaPanel.enableLink(metaPanel.geotagLink);
		metaPanel.showPimp();
		metaPanel.enableLink(metaPanel.spotLink);
	},

	disableLink: function(link) {
		
		link.className = metaPanel.metaFormDisabledClassName;
		link.disabled = true;
	},

	enableLink: function(link) {
		
		link.className = metaPanel.metaFormEnabledClassName;
		link.disabled = false;
	},

	showPimp: function() {

		$('pimp_button_cell').style.width = '170px';
		$('pimp_img').style.display = 'block';
		$('pimp_button').style.display = 'block';
	},

	hidePimp: function() {

		$('pimp_button_cell').style.width = 'auto';
		$('pimp_img').style.display = 'none';
		$('pimp_button').style.display = 'none';
	},
	
	/**
	 * updateBatchSize computes the size of the current batch and displays it
	 */
	updateBatchSize: function() {
		
		var count = window.photoview.photoCount();
		if (count == 1) {
			string = tr("Upload 1 photo");
		} else {
			string = tr("Upload %1 photos").arg(count);
		}
		$('upload_button').innerHTML = string;
	},
	
	dataChanged: function(from, to) {
		if (metaPanel.lastSelection.length != 1)
			return;
		var selectedPhoto = metaPanel.lastSelection[0];
		if (selectedPhoto >= from.row && to.row >= selectedPhoto) {
			metaPanel.refresh();
		}
	},
	
	albumModelLoaded: function() {
		
		var albums = albumsmodel.albumSelectionJSON().parseJSON().albums;
		var selectBox = $('album_select_box');
		selectBox.innerHTML = '';
		for (var i = 0; i < albums.length; i++) {
			selectBox.insert(templates.process('photouploader.album', { album: albums[i] }));
		}
	}
};

function callOnAllDaughters(node, fn) {
	
	var children = node.childNodes;
	for (var i = 0; i < children.length; i++) {
		if (children[i] != undefined) {
			if (children[i].tagName != undefined) {
				callOnAllDaughters(children[i], fn);
			}
			fn(children[i]);
		}
	}
};

function uniquifyTags(str) {
	
	var ret = [];
	str = str.replace(/[^\w\s]+/g, ""); // just mimicing the website behaviour
	var l = str.split(/\s+/);
	var h = {};
	for (var i = 0; i < l.length; i++) {
		if ((l[i] != undefined) && (l[i].search(/\S/) >= 0) && !(l[i] in h)) {
			ret.push(l[i]);
			h[l[i]] = true;
		}
	}
	return ret.join(" ");
};
