function windowResized(x, y) {
	
	setTimeout(function() {
		var leftColumn = $('left_column');
		var photoview = $('photoview');
		photoview.style.width = (leftColumn.offsetWidth - 20) + 'px';
		photoview.style.height = (leftColumn.offsetHeight - 20 - $('photo_taskbar').offsetHeight) + 'px';
		
		// FIXME: Let mainwindow know after the first successful resize.
		// This ensure that we are already laid out correctly and the
		// mainwindow can now show modal dialogs in initialized().
		if (!windowResized.first_resize) {
			windowResized.first_resize = true;
			mainwindow.initialized();
		}
	}, 50);
}

function init() {
	
	staticTexts.init("main.html");
	metaPanel.init();
	photoTaskbar.init();
	keyboard.init();
	toUploadTab.init();
	
	window.log = logging.getLogger('MainHtml');

	window.extender.connect('acceskeyhandler', 'navigationKeyPressed(QString)', 'keyboard.accessKeyEventHandler');
	window.extender.connect('albumsmodel', 'albumSelectionChanged()', 'metaPanel.albumModelLoaded');
	window.extender.connect('friendsmodel', 'loadFinished()', 'metaPanel.updateSpots');
	window.extender.connect('mainwindow', 'tabSwitchUploading()', 'toUploadTab.obscured');
	window.extender.connect('mainwindow', 'tabSwitchToUpload()', 'toUploadTab.active');
	window.extender.connect('photoeditor', 'editingStarted()', 'metaPanel.update');
	window.extender.connect('photomodel', 'layoutChanged()', 'metaPanel.photoOrderChanged');
	window.extender.connect('photomodel', 'loadingStarted()', 'toUploadTab.thumbnailingStarted');
	window.extender.connect('photomodel', 'loadingFinished(int,int)', 'toUploadTab.thumbnailingFinished');
	window.extender.connect('photomodel', 'uploadStarted()', 'photoTaskbar.uploadStarted');
	window.extender.connect('photomodel', 'uploadFinished(bool)', 'photoTaskbar.uploadFinished');
	window.extender.connect('photomodel', 'dataChanged(QModelIndex, QModelIndex)', 'metaPanel.dataChanged');
	window.extender.connect('photomodel', 'imageRotated()', 'metaPanel.update');
	window.extender.connect('photoview', 'selectionChanged()', 'update');
	window.extender.connect('photoview', 'photosChanged()', 'photoTaskbar.updateButtonStates');
	window.extender.connect('photoview', 'photosChanged()', 'metaPanel.updateBatchSize');
	window.extender.connect('photoview', 'photoCountChanged()', 'metaPanel.updateMarketingPanelVisibility');
	window.extender.connect('photoviewkeyhandler', 'navigationKeyPressed(QString)', 'keyboard.photoviewKeyEventHandler');
	window.extender.connect('uploadview', 'selectionChanged()', 'update');
}

function update() {
	metaPanel.update();
	photoTaskbar.update();
}

function save() {
	metaPanel.save();
}

function logout() {
	
	var logoutForm = document.forms.logout_form;
	var logoutAction = window.mainwindow.serverData("logout_action", "");
	if (logoutAction != "") {
		logoutForm.action = logoutAction;
		if (window.mainwindow.quit(true))
			logoutForm.submit();
	}
}

